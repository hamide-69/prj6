import React  from 'react';
import Slideshow from './Slideshow'


function Home() {
    return (
        <div>
        <Slideshow />
  
        <h1>Home Page</h1>
  
     </div>
    );
  
}

export default Home; 
