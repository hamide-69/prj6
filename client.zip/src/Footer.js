import React from 'react'

function Footer(){
    return(
        <footer>Design By HMD</footer>
    )


}

export default Footer