import React  from 'react';


function NotFound() {
    return (
        <div>
<p className=" " >404</p>  
        <h1>this Page Not Found</h1>
  
     </div>
    );
  
}

export default NotFound;
